from django.urls import path
from .views import StaffRoleView

urlpatterns = [
    path('roles/', StaffRoleView.as_view(), name='staff-roles'),
]

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ManagerViewSet, InternViewSet, StaffRoleView

router = DefaultRouter()
router.register(r'managers', ManagerViewSet)
router.register(r'interns', InternViewSet)

urlpatterns = [
    path('roles/', StaffRoleView.as_view(), name='staff-roles'),
    path('', include(router.urls)),
]
